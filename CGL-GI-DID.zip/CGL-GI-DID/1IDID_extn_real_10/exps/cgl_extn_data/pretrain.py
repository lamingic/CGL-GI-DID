# file: pretrain.py

import torch
import torch.autograd as autograd
from torch.autograd import Variable
import itertools
import numpy as np

import models_cgl
from train_cgl import getArgs, getData
from run_cgl import file2origin_data

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
cuda = True if torch.cuda.is_available() else False
Tensor = torch.cuda.FloatTensor if cuda else torch.FloatTensor


def train_aae_for_augmentation(args, data):
    """
    使用 WDAE 的训练逻辑来预训练 AAE。
    这个函数现在会返回训练好的 Decoder 部分。
    """
    print("--- Pre-training AAE for data augmentation ---")
    encoder = models_cgl.EncoderAAE(args).to(device)
    decoder = models_cgl.DecoderAAE(args).to(device)
    discriminator = models_cgl.DiscriminatorAAE(args).to(device)

    pixelwise_loss = torch.nn.L1Loss()
    optimizer_G = torch.optim.Adam(itertools.chain(encoder.parameters(), decoder.parameters()), lr=args.lr,
                                   betas=(args.b1, args.b2))
    optimizer_D = torch.optim.Adam(discriminator.parameters(), lr=args.lr, betas=(args.b1, args.b2))

    for epoch in range(args.pretrain_epochs):
        for i, x in enumerate(data):
            real_data = Variable(torch.unsqueeze(x.type(Tensor), 0), requires_grad=True).to(device)

            # --- 训练判别器 ---
            optimizer_D.zero_grad()
            z_real = Variable(Tensor(np.random.normal(0, 1, (args.batch_size, args.latent_dim))),
                              requires_grad=True).to(device)
            z_fake = encoder(real_data)
            d_loss = -torch.mean(discriminator(z_real)) + torch.mean(discriminator(z_fake.detach()))  # 使用 detach
            d_loss.backward()
            optimizer_D.step()

            # --- 训练生成器 (Encoder-Decoder) ---
            optimizer_G.zero_grad()
            decoded_data = decoder(z_fake)
            # 重建损失 + 对抗损失
            g_loss = 0.999 * pixelwise_loss(decoded_data, real_data) - 0.001 * torch.mean(discriminator(z_fake))
            g_loss.backward()
            optimizer_G.step()

        print(
            f"[AAE Pre-train Epoch {epoch + 1}/{args.pretrain_epochs}] [D loss: {d_loss.item()}] [G loss: {g_loss.item()}]")
    return decoder


def pretrain_models_main():
    args = getArgs()
    # 以 tiger, T=3 为例进行预训练
    res = file2origin_data('tiger', 3, 2)
    _, data = getData(res, 3)
    args.input_size = len(data[0])
    args.one_hot_len = 3

    # 预训练 AAE 并获取其解码器
    aae_decoder = train_aae_for_augmentation(args, data)

    # 1. 保存 AAE 的解码器作为 aae_generator_aug.pth
    torch.save(aae_decoder.state_dict(), 'aae_generator_aug.pth')
    print("AAE Generator (Decoder) saved to aae_generator_aug.pth")

    # 2. 同时，我们也用这个训练好的解码器作为 WGAN-div 生成器的占位符
    torch.save(aae_decoder.state_dict(), 'wgan_generator_aug.pth')
    print("Saved a placeholder for WGAN-div generator using the trained AAE decoder.")


if __name__ == '__main__':
    pretrain_models_main()