# file: train_cgl.py
# 包含 CGL 框架的核心训练逻辑 (Algorithm 1 和 2)。

import argparse
import torch
import torch.nn.functional as F
from torch.autograd import Variable
import torch.autograd as autograd
import numpy as np

import models_cgl

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
cuda = True if torch.cuda.is_available() else False
Tensor = torch.cuda.FloatTensor if cuda else torch.FloatTensor


def getArgs():
    parser = argparse.ArgumentParser()
    # 通用参数
    parser.add_argument("--n_epochs", type=int, default=200, help="number of epoch of training")
    parser.add_argument("--batch_size", type=int, default=1, help="size of the batches")
    parser.add_argument("--lr", type=float, default=0.0002, help="adam: learning rate")
    parser.add_argument("--b1", type=float, default=0.5, help="adam: decay of first order momentum of gradient")
    parser.add_argument("--b2", type=float, default=0.999, help="adam: decay of first order momentum of gradient")
    parser.add_argument("--latent_dim", type=int, default=10, help="dimensionality of the latent space for AAE/WGAN")
    # CGL 特有参数
    parser.add_argument("--tau", type=float, default=0.07, help="temperature for contrastive learning loss")
    parser.add_argument("--cgl_epochs", type=int, default=50, help="epochs for CGL encoder training")
    parser.add_argument("--recon_epochs", type=int, default=200, help="epochs for reconstruction generator training")
    parser.add_argument("--pretrain_epochs", type=int, default=100, help="epochs for pre-training augmenters")
    args = parser.parse_args()
    return args


def getData(data=[], action=2):
    source = data
    new_data = []
    for item in data:
        tmp_item = []
        for i in item:
            tmp_i = [0] * action
            tmp_i[i] = 1
            tmp_item.extend(tmp_i)
        new_data.append(tmp_item)
    data = torch.tensor(new_data, dtype=torch.float32)  # 使用 float32
    return source, data


def out_output(out, args):
    output = []
    for i in range(len(out) // args.one_hot_len):
        slice_node = out[i * args.one_hot_len:(i + 1) * args.one_hot_len]
        slice_node = list(slice_node.cpu().numpy())
        output.append((slice_node.index(max(slice_node))))
    return output


def info_nce_loss(features, tau):
    features = F.normalize(features, dim=1)
    similarity_matrix = torch.matmul(features, features.T)

    batch_size = features.shape[0] // 2
    labels = torch.cat([torch.arange(batch_size) for _ in range(2)], dim=0)
    labels = (labels.unsqueeze(0) == labels.unsqueeze(1)).float().to(device)

    mask = torch.eye(labels.shape[0], dtype=torch.bool).to(device)
    labels = labels[~mask].view(labels.shape[0], -1)
    similarity_matrix = similarity_matrix[~mask].view(similarity_matrix.shape[0], -1)

    positives = similarity_matrix[labels.bool()].view(labels.shape[0], -1)
    negatives = similarity_matrix[~labels.bool()].view(similarity_matrix.shape[0], -1)

    logits = torch.cat([positives, negatives], dim=1)
    labels = torch.zeros(logits.shape[0], dtype=torch.long).to(device)

    logits = logits / tau
    return logits, labels


def train_cgl_encoder(args, data, aae_encoder, aae_generator, wgan_generator):
    """
    实现 Algorithm 1: 训练 CGL Encoder 和 Projector
    """
    print("--- Starting CGL Encoder Training (Algorithm 1) ---")
    encoder = models_cgl.EncoderCGL(args).to(device)
    projector = models_cgl.Projector(feature_dim=encoder.feature_dim).to(device)

    optimizer = torch.optim.Adam(
        list(encoder.parameters()) + list(projector.parameters()),
        lr=args.lr, betas=(args.b1, args.b2)
    )
    criterion = torch.nn.CrossEntropyLoss().to(device)

    for epoch in range(args.cgl_epochs):
        for i, x in enumerate(data):
            x = Variable(torch.unsqueeze(x.type(Tensor), 0)).to(device)

            with torch.no_grad():
                # --- 修改部分: 修正 AAE 的增强逻辑 ---
                z_aae = aae_encoder(x)
                aug_x1 = aae_generator(z_aae)

                z_wgan = Variable(Tensor(np.random.normal(0, 1, (x.size(0), args.latent_dim)))).to(device)
                aug_x2 = wgan_generator(z_wgan)

            features1 = encoder(aug_x1)
            features2 = encoder(aug_x2)

            projections1 = projector(features1)
            projections2 = projector(features2)

            all_projections = torch.cat([projections1, projections2], dim=0)
            logits, labels = info_nce_loss(all_projections, args.tau)
            loss = criterion(logits, labels)

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

        print(f"[CGL Epoch {epoch + 1}/{args.cgl_epochs}] [Loss: {loss.item()}]")

    print("--- CGL Encoder Training Done! ---")
    return encoder


def train_recon_generator(args, data, cgl_encoder):
    """
    实现 Algorithm 2: 训练行为重建生成器
    """
    print("--- Starting Behavior Reconstruction Training (Algorithm 2) ---")
    cgl_encoder.eval()
    for param in cgl_encoder.parameters():
        param.requires_grad = False

    generator = models_cgl.GeneratorRecon(args, feature_dim=cgl_encoder.feature_dim).to(device)
    discriminator = models_cgl.DiscriminatorRecon(args).to(device)

    optimizer_G = torch.optim.Adam(generator.parameters(), lr=args.lr, betas=(args.b1, args.b2))
    optimizer_D = torch.optim.Adam(discriminator.parameters(), lr=args.lr, betas=(args.b1, args.b2))

    for epoch in range(args.recon_epochs):
        for i, real_data in enumerate(data):
            real_data = Variable(torch.unsqueeze(real_data.type(Tensor), 0), requires_grad=True).to(device)

            # --- 训练判别器 ---
            optimizer_D.zero_grad()

            with torch.no_grad():
                features = cgl_encoder(real_data)

            fake_data = generator(features)

            real_validity = discriminator(real_data)
            fake_validity = discriminator(fake_data.detach())

            alpha = Tensor(np.random.random((real_data.size(0), 1))).to(device)
            interpolates_data = (alpha * real_data.data + ((1 - alpha) * fake_data.data))
            interpolates = Variable(interpolates_data, requires_grad=True)

            d_interpolates = discriminator(interpolates)

            grad_outputs = Variable(Tensor(d_interpolates.size()).fill_(1.0), requires_grad=False).to(device)

            gradients = autograd.grad(
                outputs=d_interpolates,
                inputs=interpolates,
                grad_outputs=grad_outputs,
                create_graph=True,
                retain_graph=True,
                only_inputs=True,
            )[0]
            gradients = gradients.view(gradients.size(0), -1)
            gradient_penalty = ((gradients.norm(2, dim=1) - 1) ** 2).mean()

            d_loss = -torch.mean(real_validity) + torch.mean(fake_validity) + 10 * gradient_penalty

            d_loss.backward()
            optimizer_D.step()

            # --- 训练生成器 ---
            if i % 5 == 0:
                optimizer_G.zero_grad()
                features = cgl_encoder(real_data)
                gen_data = generator(features)
                g_loss = -torch.mean(discriminator(gen_data))
                g_loss.backward()
                optimizer_G.step()

        # 打印最后一个 batch 的损失
        print(f"[Recon Epoch {epoch + 1}/{args.recon_epochs}] [D loss: {d_loss.item()}] [G loss: {g_loss.item()}]")

    print("--- Behavior Reconstruction Training Done! ---")
    return generator