import torch
import torch.nn as nn
from torch.autograd import Variable
from torch import Tensor
import numpy as np

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
cuda = True if torch.cuda.is_available() else False
Tensor = torch.cuda.FloatTensor if cuda else torch.FloatTensor

# ---------------------------------------------------------------------------- #
# Component 1: CGL Encoder (f_ψ) and Projector (g_φ) for Algorithm 1
# ---------------------------------------------------------------------------- #

class EncoderCGL(nn.Module):
    """
    CGL 特征编码器 (f_ψ).
    与 WDAE 的 Encoder 不同，它不进行变分推理，直接输出特征。
    """
    def __init__(self, args):
        super(EncoderCGL, self).__init__()
        self.feature_dim = 512 # 定义特征维度
        self.model = nn.Sequential(
            nn.Linear(args.input_size, 512),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(512, self.feature_dim),
            nn.LeakyReLU(0.2, inplace=True),
        )

    def forward(self, data):
        features = self.model(data)
        return features

class Projector(nn.Module):
    """
    对比学习用的投影头 (g_φ).
    """
    def __init__(self, feature_dim, projection_dim=128):
        super(Projector, self).__init__()
        self.model = nn.Sequential(
            nn.Linear(feature_dim, 512),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(512, projection_dim)
        )

    def forward(self, features):
        projection = self.model(features)
        return projection

# ---------------------------------------------------------------------------- #
# Component 2: Behavior Reconstruction Models for Algorithm 2
# ---------------------------------------------------------------------------- #

class GeneratorRecon(nn.Module):
    """
    行为重建生成器 (G_ζ).
    结构与 WDAE 的 Decoder 类似，但输入是 EncoderCGL 提取的特征。
    """
    def __init__(self, args, feature_dim=512):
        super(GeneratorRecon, self).__init__()
        self.model = nn.Sequential(
            nn.Linear(feature_dim, 512),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(512, 512),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(512, args.input_size),
            nn.Tanh(),
        )

    def forward(self, features):
        recon_data = self.model(features)
        return recon_data

class DiscriminatorRecon(nn.Module):
    """
    行为重建判别器 (D_ε).
    输入是高维的策略树向量 X，而不是低维的 latent_dim。
    """
    def __init__(self, args):
        super(DiscriminatorRecon, self).__init__()
        self.model = nn.Sequential(
            nn.Linear(args.input_size, 512),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(512, 256),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(256, 1),
        )

    def forward(self, data):
        validity = self.model(data)
        return validity

class EncoderAAE(nn.Module):
    def __init__(self, args):
        super(EncoderAAE, self).__init__()
        # --- 第 1 处修改: 将 args 保存为实例属性 ---
        self.args = args

        self.model = nn.Sequential(
            nn.Linear(args.input_size, 512), nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(512, 512), nn.LeakyReLU(0.2, inplace=True),
        )
        self.mu = nn.Linear(512, args.latent_dim)
        self.logvar = nn.Linear(512, args.latent_dim)

    def reparameterization(self, mu, logvar):
        std = torch.exp(logvar / 2)
        sampled_z = Variable(Tensor(np.random.normal(0, 1, (mu.size(0), self.args.latent_dim))))
        z = sampled_z.to(device) * std + mu
        return z

    def forward(self, data):
        x = self.model(data)
        mu = self.mu(x)
        logvar = self.logvar(x)
        z = self.reparameterization(mu, logvar)
        return z
class DecoderAAE(nn.Module):
    def __init__(self, args):
        super(DecoderAAE, self).__init__()
        self.model = nn.Sequential(
            nn.Linear(args.latent_dim, 512), nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(512, 512), nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(512, args.input_size), nn.Tanh(),
        )

    def forward(self, z):
        return self.model(z)

class DiscriminatorAAE(nn.Module):
    def __init__(self, args):
        super(DiscriminatorAAE, self).__init__()
        self.model = nn.Sequential(
            nn.Linear(args.latent_dim, 512), nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(512, 256), nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(256, 1), nn.Sigmoid(),
        )

    def forward(self, z):
        return self.model(z)

# WGAN-div for augmentation
GeneratorWGAN = DecoderAAE # 结构相同，输入是噪声
DiscriminatorWGAN = DiscriminatorRecon # 结构相同，输入是数据