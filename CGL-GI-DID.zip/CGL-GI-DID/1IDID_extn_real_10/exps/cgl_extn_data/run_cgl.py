# file: run_cgl.py
# 步骤 2: 在 pretrain.py 运行之后，运行此脚本以执行完整的 CGL 流程。

import copy
import datetime
from pprint import pprint
import numpy as np
import torch
from torch.autograd import Variable

import models_cgl
from train_cgl import getArgs, getData, train_cgl_encoder, train_recon_generator, out_output
from utils_cgl import *

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
Tensor = torch.cuda.FloatTensor if torch.cuda.is_available() else torch.FloatTensor


# 1. 在pretrain.py中选择demo进行预训练。
# 2. 运行run.cgl.py生成决策树 结果放在data目录下

class PreTreeNode:
    def __init__(self, action=-1):
        self.action = action
        self.obs = []


def genTree(paths, obs=2):
    res = []
    rootval = int(paths[0][1])
    root = PreTreeNode(rootval)
    for item in paths:
        cur = root
        for index in range(1, len(item) // 2):
            o = int(item[2 * index])
            a = int(item[2 * index + 1])
            if not cur.obs:
                cur.obs = [{} for _ in range(obs)]
            newnode = PreTreeNode(a)
            if a not in cur.obs[o - 1]:
                cur.obs[o - 1][a] = newnode
                cur = newnode
            else:
                cur = cur.obs[o - 1][a]
    return root


def pprintTree(root, obs=2):
    stack = [root]
    node_log = []
    while stack:
        node = stack.pop()
        node_log.append(node.action)
        for actiondict in node.obs:
            if actiondict:
                for newnode in actiondict.values():
                    stack.insert(0, newnode)
    return node_log


def file2origin_data(domain, time_slice=3, obs=2):
    data_c = []
    with open('./data/raw_data/' + domain + '_{}_7.txt'.format(time_slice), 'r', encoding='utf-8') as f:
        for line in f:
            line_paths = line.split()
            res = []
            for path in line_paths:
                if 'a' in path:
                    res.append(path[1::2])
            if len(res) == 0:
                continue  # 跳过空行
            test = ['0' + i for i in res]
            node = genTree(test, obs)
            data_c.append(pprintTree(node))
        data_c = node_reduce(data_c)
    return data_c


def file2origin_data1(domain, time_slice=3, obs=2):
    data_c = []
    with open('./data/raw_data/' + domain + '_{}_7.txt'.format(time_slice), 'r', encoding='utf-8') as f:
        for line in f:
            line_paths = line.split()
            res = []
            for path in line_paths:
                if 'a' in path:
                    res.append(path[1::2])
            if len(res) == 0:
                continue
            res = get_Uav4_data(res)
            test = ['0' + i for i in res]
            node = genTree(test, obs)
            data_c.append(pprintTree(node))
        data_c = node_reduce(data_c)
    return data_c


def file2origin_data5(file_name, time_slice=3, obs=2):
    data_c = []
    with open('./data/raw_data/' + file_name + '_{}_7.txt'.format(time_slice), 'r', encoding='utf-8') as f:
        for line in f:
            line_paths = line.split('，')
            test = ['0' + i.strip() for i in line_paths]
            node = genTree(test, obs)
            data_c.append(pprintTree(node))
        data_c = node_reduce(data_c)
    return data_c


def node_reduce(res):
    try:
        for i in range(len(res)):
            for j in range(len(res[0])):
                res[i][j] -= 1
    except:
        pprint(res)
    return res


# --- 核心逻辑 ---
def inference_cgl(cgl_encoder, recon_generator, data, args, M=150):
    """
    实现 Algorithm 3 的生成部分 (lines 4-11)
    """
    cgl_encoder.eval()
    recon_generator.eval()

    output_x = []
    with torch.no_grad():
        for i in range(M):
            idx = np.random.randint(0, len(data))
            x_n = data[idx]
            x_n = Variable(torch.unsqueeze(x_n.type(Tensor), 0)).to(device)

            u_n = cgl_encoder(x_n)
            x_tilde_n = recon_generator(u_n)

            mu = np.random.random()
            x_hat_n = (1 - mu) * x_n + mu * x_tilde_n

            output_x.append(out_output(x_hat_n[0], args))

    recon = [list(l) for l in set([tuple(k) for k in output_x])]
    return recon


def get_result_cgl(domain='tiger', time_slice=3):
    obs = 2 if domain == 'tiger' else 4
    action = 3 if domain == 'tiger' else 5

    if domain == 'uav' and time_slice == 4:
        res = file2origin_data1(domain, time_slice - 1, obs)
    elif domain == 'tiger' and time_slice == 5:
        res = file2origin_data5(domain, time_slice, obs)
    else:
        res = file2origin_data(domain, time_slice, obs)

    args = getArgs()
    _, data = getData(res, action)
    args.input_size = len(data[0])
    args.one_hot_len = action

    # ====== CGL 训练流水线 ======

    # 1. 加载预训练好的数据增强模型
    print("Loading pre-trained data augmentation models...")

    # --- 创建 AAE 的 Encoder 和 Decoder ---
    aae_encoder_aug = models_cgl.EncoderAAE(args).to(device)
    aae_encoder_aug.eval()

    aae_gen_aug = models_cgl.DecoderAAE(args).to(device)
    aae_gen_aug.load_state_dict(torch.load('aae_generator_aug.pth'))
    aae_gen_aug.eval()

    # WGAN-div 生成器直接从噪声生成
    wgan_gen_aug = models_cgl.GeneratorWGAN(args).to(device)
    wgan_gen_aug.load_state_dict(torch.load('wgan_generator_aug.pth'))
    wgan_gen_aug.eval()

    # 阶段 1: 训练 CGL Encoder (Algorithm 1)
    cgl_encoder = train_cgl_encoder(args, data, aae_encoder_aug, aae_gen_aug, wgan_gen_aug)

    # 阶段 2: 训练行为重建生成器 (Algorithm 2)
    recon_generator = train_recon_generator(args, data, cgl_encoder)

    # ====== CGL 生成与筛选 ======
    time1 = datetime.datetime.now()
    print("====== CGL res ==========")

    generated_policies = inference_cgl(cgl_encoder, recon_generator, data, args)
    print(f"{domain} T={time_slice} -- Generated {len(generated_policies)} unique policies")

    time2 = datetime.datetime.now()

    k = 10 if len(generated_policies) > 10 else len(generated_policies)
    if not generated_policies:
        print("Warning: No policies were generated. Skipping selection.")
        selected_policies = []
    else:
        selected_policies = topk_select_MDF(generated_policies, k=k, obs=obs, time=time_slice)

    time3 = datetime.datetime.now()
    print("生成花费时间：", time2 - time1)
    print("选择花费时间：", time3 - time2)
    print("整个花费时间：", time3 - time1)

    getdata2file(selected_policies, 'cgl', domain, time_slice, action, obs)

if __name__ == '__main__':
    for domain in ['tiger']:  # , 'uav']:
        for time_slice in [3]:  # , 4]:
            get_result_cgl(domain=domain, time_slice=time_slice)