# AAE模型
import torch
import torch.nn as nn
from torch.autograd import Variable
from torch import Tensor
import numpy as np

class Encoder(nn.Module):
    def __init__(self, args):
        super(Encoder, self).__init__()

        self.model = nn.Sequential(
            nn.Linear(args.input_size, 512),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(512, 512),
            nn.LeakyReLU(0.2, inplace=True),
        )

        self.mu = nn.Linear(512, args.latent_dim)
        self.logvar = nn.Linear(512, args.latent_dim)

    def reparameterization(self, mu, logvar):
        std = torch.exp(logvar / 2)
        sampled_z = Variable(Tensor(np.random.normal(0, 1, (mu.size(0), 10))))

        z = sampled_z * std + mu
        return z

    def forward(self, data):
        x = self.model(data)
        mu = self.mu(x)
        logvar = self.logvar(x)
        z = self.reparameterization(mu, logvar)
        return z


class Decoder(nn.Module):
    def __init__(self, args):
        super(Decoder, self).__init__()

        self.model = nn.Sequential(
            nn.Linear(args.latent_dim, 512),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(512, 512),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(512, args.input_size),
            nn.Tanh(),
        )

    def forward(self, z):
        data = self.model(z)
        return data


class Discriminator(nn.Module):
    def __init__(self, args):
        super(Discriminator, self).__init__()

        self.model = nn.Sequential(
            nn.Linear(args.latent_dim, 512),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(512, 256),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(256, 1),
            nn.Sigmoid(),
        )

    def forward(self, data):
        validity = self.model(data)
        return validity




