import copy
import random
from pprint import pprint
from train_wgan_div import *
from utils_wgan_div import *
from utils_wgan_div import getdata2file


# 创建 TreeNode
class PreTreeNode:
    def __init__(self, action=-1):
        self.action = action
        self.obs = []

def genTree(paths, obs=2):
    # # ['011212', '011322', '012212', '012222']
    res = []
    rootval = int(paths[0][1])
    root = PreTreeNode(rootval)
    for item in paths:
        # 021112
        cur = root
        for index in range(1, len(item) // 2):
            o = int(item[2 * index])
            a = int(item[2 * index + 1])
            # print(o, a)
            if not cur.obs:
                cur.obs = [{} for _ in range(obs)]
            newnode = PreTreeNode(a)
            if a not in cur.obs[o - 1]:
                cur.obs[o - 1][a] = newnode
                cur = newnode
            else:
                cur = cur.obs[o - 1][a]
    return root

def pprintTree(root, obs=2):
    # 打印策略树
    stack = [root]
    node_log = []
    while stack:
        node = stack.pop()
        node_log.append(node.action)
        for actiondict in node.obs:
            if actiondict:
                for newnode in actiondict.values():
                    stack.insert(0, newnode)
    # print(node_log)
    return node_log


def file2origin_data(domain, time_slice = 3, obs = 2):
    data_c = []
    with open('./data/raw_data/' + domain + '_{}_7.txt'.format(time_slice), 'r', encoding='utf-8') as f:
        for line in f:
            line_paths = line.split()
            res = []
            for path in line_paths:
                if 'a' in path:
                    res.append(path[1::2])
            if len(res) == 0:
                break
            test = ['0' + i for i in res]
            node = genTree(test, obs)
            data_c.append(pprintTree(node))
        data_c = node_reduce(data_c)
    return data_c

def file2origin_data1(domain, time_slice = 3, obs = 2):
    data_c = []
    with open('./data/raw_data/' + domain + '_{}_7.txt'.format(time_slice), 'r', encoding='utf-8') as f:
        for line in f:
            line_paths = line.split()
            res = []
            for path in line_paths:
                if 'a' in path:
                    res.append(path[1::2])
            if len(res) == 0:
                break
            res = get_Uav4_data(res)
            test = ['0' + i for i in res]
            node = genTree(test, obs)
            data_c.append(pprintTree(node))
        data_c = node_reduce(data_c)
    return data_c

def file2origin_data5(file_name, time_slice = 3, obs = 2):
    data_c = []
    with open('./data/raw_data/' + file_name + '_{}_7.txt'.format(time_slice), 'r', encoding='utf-8') as f:
        for line in f:
            line_paths = line.split('，')

            test = ['0' + i.strip() for i in line_paths]
            node = genTree(test, obs)
            data_c.append(pprintTree(node))
        data_c = node_reduce(data_c)
    return data_c

def node_reduce(res):
    try:
        for i in range(len(res)):
            for j in range(len(res[0])):
                res[i][j] -= 1
    except:
        pprint(res)
    return res


def get_result(domain='tiger', time_slice=3):
    obs = 2 if domain == 'tiger' else 4
    action = 3 if domain == 'tiger' else 5
    if domain == 'uav' and time_slice == 4:
        res = file2origin_data1(domain, time_slice-1, obs)
    elif domain == 'tiger' and time_slice == 5:
        res = file2origin_data5(domain, time_slice, obs)
    else:
        res = file2origin_data(domain, time_slice, obs)
    # print('====== res =========')
    # pprint(res)

    # ====== 训练 =======
    temp = copy.deepcopy(res)
    args = getArgs()
    source, data = getData(temp, action)
    args.input_size = len(data[0])
    args.one_hot_len = action
    generator = wgan_div.Generator(args).to(device)
    discriminator = wgan_div.Discriminator(args).to(device)
    train(generator, discriminator, data, args)

    print('====== wgan-div res ==========')
    recon1 = inference(generator, data, args)
    print(domain, time_slice, "--", len(recon1))

    k = 10 if len(recon1) > 10 else len(recon1)
    rec1 = topk_select_MDF(recon1, k=k, obs=obs, time=time_slice)

    getdata2file(rec1, 'wgan_div', domain, time_slice, action, obs)


if __name__ == '__main__':
    # get_result(domain='uav', time_slice=5)
    for domain in ['tiger', 'uav']:
        for time_slice in [3, 4]:
            get_result(domain=domain, time_slice=time_slice)