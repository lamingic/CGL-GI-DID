import math
import random
from pprint import pprint


def get_prob(data_clean):
    # 返回action -> obs -> action 分支的出现次数
    # input: 所有 path 集合
    # output: aoa以及对应出现的次数
    prob = dict()
    # 给根节点置位前节点 和 前 obs
    prob_data = ['00' + i for i in data_clean]
    for item in prob_data:
        for j in range(len(item) // 2):
            tmp = item[j * 2: j * 2 + 3]
            if tmp not in prob:
                prob[tmp] = 0
            prob[tmp] += 1
    return prob


def get_Uav4_data(data):
    prob = get_prob(data)
    # print(prob)
    predict = dict()
    for key, value in prob.items():
        if key[:2] not in predict:
            predict[key[:2]] = dict()
        predict[key[:2]][key[2]] = value
    for key, value in predict.items():
        if len(value) > 1:
            sum_value = sum(value.values())
            cur = 0
            for key2, value2 in value.items():
                predict[key][key2] = (cur + value2)/sum_value
                cur += value2
    # print(predict)
    res = []
    for item in data:
        action = item[-1]
        for i in range(1, 5):
            loc = action + str(i)
            if loc not in predict:
                res.append(item + str(i) + '1')
            else:
                candidate = sorted(predict[loc].items(), key=lambda x: x[1])
                if len(candidate) == 1:
                    res.append(item + str(i) + candidate[0][0])
                else:
                    random_ = random.random()
                    for cand in candidate:
                        if cand[1] >= random_:
                            res.append(item + str(i) + cand[0])
                            break
    return res


def topk_select_MDF(res, k, obs, time):
    # 根据树的策略选择，贪心的方式计算得到k个策略树，使得这k个策略树的多样性得到最大
    # len(res) > k
    # 选两棵树达到最大，选第三棵树达到最大，选第k棵树达到最大
    # ------------- 判定符合要求 -------------
    if len(res) < k:
        print('ERROR')
        return res
    elif len(res) == k:
        return res
    # ------------ 确定 2 棵树达到最大多样性的 2 颗策略树 ---------
    max2tree = []
    max2diver = -1
    for i in range(len(res)):
        for j in range(i + 1, len(res)):
            tmp2tree = [res[i], res[j]]
            tmp_diver = compute_MDF_diversity(tmp2tree, obs, time)
            if tmp_diver > max2diver:
                max2diver = tmp_diver
                max2tree = tmp2tree
    # ------------ 从两棵树扩展到 k 棵树 ---------
    trees = [tuple(item) for item in max2tree]
    while len(trees) < k:
        max_divers = -1
        max_tmp = []
        for item in res:
            if tuple(item) not in trees:
                tmp = [list(i) for i in trees] + [item]
                divers = compute_MDF_diversity(tmp, obs, time)
                if divers > max_divers:
                    max_tmp = tmp
                    max_divers = divers
        trees = max_tmp
    print("diversity:", max_divers)
    return trees

def compute_MDF_diversity(trees, obs, time):
    diff_seq = set()
    diff_sub_f = set()
    # sum_mdf = 0
    for item in trees:
        # -------- get diff sub f ----------
        frames = [obs ** i for i in range(time)]
        for i in range(time):
            diff_sub_f.add(tuple(item[:sum(frames[:i + 1])]))
            
        # ---------- get diff seq ----------
        # 1. get paths
        paths = [[0] * (2 * time - 1) for _ in range(obs ** (time - 1))]
        for k in range(len(paths)):
            for i in range(time - 1):
                paths[k][i * 2 + 1] = (k // (obs ** (time - i - 2))) % obs

        ind_start = 0
        for cl in range(0, time, 1):
            step = (obs ** cl)
            copy = (obs ** (time - cl - 1))
            ind_end = int(ind_start + step)
            elements = [item[i] for i in range(ind_start, ind_end)]
            ind_start = ind_end
            column = [e for e in elements for i in range(0, copy)]
            for i in range(0, len(column)):
                paths[i][cl * 2] = column[i]

        for path in paths:
            for i in range(time):
                diff_seq.add(tuple(path[:i * 2 + 1]))
        sum_mdf = 0
        sum_mdf += len(diff_sub_f)
        sum_mdf += len(diff_seq)
    # print(sum_mdf)
    mdf = sum_mdf/(obs ** (time - 1))
    # print(mdf)
    return mdf


#  
def getdata2file(data, pattern = '', file_name = 'tiger', time = 3, action = 3, obs = 2):
    f = open('./data/{}{}/'.format(file_name, time) + file_name + '_' + pattern + '_{}_0.txt'.format(time), 'w', encoding='utf8')
    for item in data:
        paths = [[0] * (2 * time - 1) for _ in range(obs ** (time - 1))]
        for k in range(len(paths)):
            for i in range(time - 1):
                paths[k][i * 2 + 1] = (k // (obs ** (time - i - 2))) % obs

        ind_start = 0
        for cl in range(0, time, 1):
            step = (obs ** cl)
            copy = (obs ** (time - cl - 1))
            ind_end = int(ind_start + step)
            elements = [item[i] for i in range(ind_start, ind_end)]
            ind_start = ind_end
            column = [e for e in elements for i in range(0, copy)]
            for i in range(0, len(column)):
                paths[i][cl * 2] = column[i]
        f.write('0.25\n')
        for item in paths:
            item = [str(i) for i in item]
            f.write(' '.join(item) + '\n')
        f.write('\n')


if __name__ == '__main__':

    # recon = [[2, 2, 2, 1, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0]]
    # getdata2file(recon, 'wdae', 'tiger', 4, 3, 2)
    get_Uav4_data()