import math
import random
from pprint import pprint
import datetime


def topk_select_MDF(res, k, obs, time):
    # ------------- 判定符合要求 -------------
    if len(res) < k:
        print('ERROR')
        return res
    elif len(res) == k:
        return res
    # ------------ 确定 2 棵树达到最大多样性的 2 颗策略树 ---------
    max2tree = []
    max2diver = -1
    for i in range(len(res)):
        for j in range(i + 1, len(res)):
            tmp2tree = [res[i], res[j]]
            tmp_diver = compute_MDF_diversity(tmp2tree, obs, time)
            if tmp_diver > max2diver:
                max2diver = tmp_diver
                max2tree = tmp2tree
    # ------------ 从两棵树扩展到 k 棵树 ---------
    trees = [tuple(item) for item in max2tree]
    while len(trees) < k:
        max_divers = -1
        max_tmp = []
        for item in res:
            if tuple(item) not in trees:
                tmp = [list(i) for i in trees] + [item]
                divers = compute_MDF_diversity(tmp, obs, time)
                if divers > max_divers:
                    max_tmp = tmp
                    max_divers = divers
        trees = max_tmp
        print(divers)
    return trees

def compute_MDF_diversity(trees, obs, time):
    diff_seq = set()
    diff_sub_f = set()
    # sum_mdf = 0
    for item in trees:
        # -------- get diff sub f ----------
        frames = [obs ** i for i in range(time)]
        for i in range(time):
            diff_sub_f.add(tuple(item[:sum(frames[:i + 1])]))

        # ---------- get diff seq ----------
        # 1. get paths
        paths = [[0] * (2 * time - 1) for _ in range(obs ** (time - 1))]
        for k in range(len(paths)):
            for i in range(time - 1):
                paths[k][i * 2 + 1] = (k // (obs ** (time - i - 2))) % obs

        ind_start = 0
        for cl in range(0, time, 1):
            step = (obs ** cl)
            copy = (obs ** (time - cl - 1))
            ind_end = int(ind_start + step)
            elements = [item[i] for i in range(ind_start, min(ind_end, len(item)))]
            ind_start = ind_end
            column = [e for e in elements for i in range(0, copy)]
            for i in range(0, len(column)):
                paths[i][cl * 2] = column[i]

        for path in paths:
            for i in range(time):
                diff_seq.add(tuple(path[:i * 2 + 1]))
        sum_mdf = 0
        sum_mdf += len(diff_sub_f)
        sum_mdf += len(diff_seq)
    # print(sum_mdf)
    # 遍历每一颗树，逐步确定分子集合
    #
    mdf = sum_mdf/(obs ** (time - 1))
    # print(mdf)
    return mdf


def out_output(out, action):
    output = []

    for i in range(len(out) // action):
        slice_node = out[i * action:(i + 1) * action ]
        slice_node = list(slice_node)
        # print(max(slice_node))
        # print(slice_node.index(max(slice_node)))
        output.append((slice_node.index(max(slice_node))))
    return output

#  
def getdata2file(data, pattern = '', file_name = 'tiger', time = 3, action = 3, obs = 2):
    c_time = datetime.datetime.now().strftime('%m%d-%H%M%S')
    f = open('./data/{}{}/'.format(file_name, time) + file_name + '_' + pattern + '{}_{}.txt'.format(time, c_time), 'w', encoding='utf8')
    for item in data:
        paths = [[0] * (2 * time - 1) for _ in range(obs ** (time - 1))]
        for k in range(len(paths)):
            for i in range(time - 1):
                paths[k][i * 2 + 1] = (k // (obs ** (time - i - 2))) % obs

        ind_start = 0
        for cl in range(0, time, 1):
            step = (obs ** cl)
            copy = (obs ** (time - cl - 1))
            ind_end = int(ind_start + step)
            elements = [item[i] for i in range(ind_start, min(ind_end, len(item)))]
            ind_start = ind_end
            column = [e for e in elements for i in range(0, copy)]
            for i in range(0, len(column)):
                paths[i][cl * 2] = column[i]
        # other = 0
        # for i in range(time):
        #     other += obs ** (i - 1) if i != 0 else 0
        #     for k in range(len(paths)):
        #         paths[k][i * 2] = item[other + k % (obs ** i)]
        # print(paths)
        f.write('0.25\n')
        for item in paths:
            item = [str(i) for i in item]
            f.write(' '.join(item) + '\n')
        f.write('\n')

if __name__ == '__main__':

    # recon = [[2, 2, 2, 1, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0]]
    # getdata2file(recon, 'gan', 'tiger', 4, 3, 2)
    # file2origin_data('tiger')
    # get_Tiger3_data()
    get_Uav4_data()