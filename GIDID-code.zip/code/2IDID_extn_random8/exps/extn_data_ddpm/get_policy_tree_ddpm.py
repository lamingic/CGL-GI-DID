import copy
import random
from pprint import pprint

from utils_ddpm import *
from utils_ddpm import getdata2file
# from ddpm_gen import *
import torch

# 创建 TreeNode
class PreTreeNode:
    def __init__(self, action=-1):
        self.action = action
        self.obs = []

def genTree(paths, obs=2):
    # # ['011212', '011322', '012212', '012222']
    res = []
    rootval = int(paths[0][1])
    root = PreTreeNode(rootval)
    for item in paths:
        # 021112
        cur = root
        for index in range(1, len(item) // 2):
            o = int(item[2 * index])
            a = int(item[2 * index + 1])
            # print(o, a)
            if not cur.obs:
                cur.obs = [{} for _ in range(obs)]
            newnode = PreTreeNode(a)
            if a not in cur.obs[o - 1]:
                cur.obs[o - 1][a] = newnode
                cur = newnode
            else:
                cur = cur.obs[o - 1][a]
    return root

def pprintTree(root, obs=2):
    # 打印策略树
    stack = [root]
    node_log = []
    while stack:
        node = stack.pop()
        node_log.append(node.action)
        for actiondict in node.obs:
            if actiondict:
                for newnode in actiondict.values():
                    stack.insert(0, newnode)
    print(node_log)
    return node_log

def node_reduce(res):
    try:
        for i in range(len(res)):
            for j in range(len(res[0])):
                res[i][j] -= 1
    except:
        pprint(res)
    return res

def file2origin_data(domain, time_slice = 3, obs = 2):
    data_c = []
    with open('./data/raw_data/' + domain + '_{}_7.txt'.format(time_slice), 'r', encoding='utf-8') as f:
        for line in f:
            line_paths = line.split()
            res = []
            for path in line_paths:
                if 'a' in path:
                    res.append(path[1::2])
            if len(res) == 0:
                break
            test = ['0' + i for i in res]
            node = genTree(test, obs)
            data_c.append(pprintTree(node))
        data_c = node_reduce(data_c)
    return data_c


def getData(data=[], action=2):
    source = data
    new_data = []
    for item in data:
        tmp_item = []
        for i in item:  # i= 1,1,1,-1,2,0,2
            tmp_i = [0] * action
            tmp_i[i] = 1
            tmp_item.extend(tmp_i)
        new_data.append(tmp_item)
    data = torch.tensor(new_data, dtype=torch.long)
    return source, data

def get_result(domain='tiger', time_slice=3):
    obs = 2 if domain == 'tiger' else 4
    action = 3 if domain == 'tiger' else 5
    if domain == 'uav' and time_slice == 4:
        res = file2origin_data1(domain, time_slice-1, obs, action)
    elif domain == 'tiger' and time_slice == 5:
        res = file2origin_data5(domain, time_slice, obs)
    else:
        res = file2origin_data(domain, time_slice, obs)
    temp = copy.deepcopy(res)
    source, data = getData(temp, action)
    return data, action, obs

    # 
    # temp = copy.deepcopy(res)
    # args = getArgs()
    # source, data = getData(temp, action)
    # args.input_size = len(data[0])
    # args.one_hot_len = action
    # model = wgan_div.UNetModel(args, in_channels=1, model_channels=96, out_channels=1,
    #                            channel_mult=(1, 2, 2), attention_resolutions=[]).to(device)
    # train(model, data, args)
    

def file2origin_data5(file_name, time_slice = 3, obs = 2):
    data_c = []
    with open('./data/raw_data/' + file_name + '_{}_7.txt'.format(time_slice), 'r', encoding='utf-8') as f:
        for line in f:
            line_paths = line.split('，')

            test = ['0' + i.strip() for i in line_paths]
            node = genTree(test, obs)
            data_c.append(pprintTree(node))
        data_c = node_reduce(data_c)
    return data_c

def file2origin_data1(domain, time_slice = 3, obs = 2, action=5):
    data_c = []
    with open('./data/raw_data/' + domain + '_{}_7.txt'.format(time_slice), 'r', encoding='utf-8') as f:
        for line in f:
            line_paths = line.split()
            res = []
            for path in line_paths:
                if 'a' in path:
                    res.append(path[1::2])
            if len(res) == 0:
                break
            res = get_Uav4_data(res)
            test = ['0' + i for i in res]
            node = genTree(test, obs)
            data_c.append(pprintTree(node))
        data_c = node_reduce(data_c)
    return data_c

def get_prob(data_clean):
    # 返回action -> obs -> action 分支的出现次数
    # input: 所有 path 集合
    # output: aoa以及对应出现的次数
    prob = dict()
    # 给根节点置位前节点 和 前 obs
    prob_data = ['00' + i for i in data_clean]
    for item in prob_data:
        for j in range(len(item) // 2):
            tmp = item[j * 2: j * 2 + 3]
            if tmp not in prob:
                prob[tmp] = 0
            prob[tmp] += 1
    return prob

def get_Uav4_data(data):
    prob = get_prob(data)
    # print(prob)
    predict = dict()
    for key, value in prob.items():
        if key[:2] not in predict:
            predict[key[:2]] = dict()
        predict[key[:2]][key[2]] = value
    for key, value in predict.items():
        if len(value) > 1:
            sum_value = sum(value.values())
            cur = 0
            for key2, value2 in value.items():
                predict[key][key2] = (cur + value2)/sum_value
                cur += value2
    # print(predict)
    res = []
    for item in data:
        action = item[-1]
        for i in range(1, 5):
            loc = action + str(i)
            if loc not in predict:
                res.append(item + str(i) + '1')
                # res.append(item + 'o' + str(i) + 'a1')
            else:
                candidate = sorted(predict[loc].items(), key=lambda x: x[1])
                if len(candidate) == 1:
                    res.append(item + str(i) + candidate[0][0])
                    # res.append(item + 'o' + str(i) + 'a' + candidate[0][0])
                else:
                    random_ = random.random()
                    for cand in candidate:
                        if cand[1] >= random_:
                            res.append(item + str(i) + cand[0])
                            # res.append(item + 'o' + str(i) + 'a' + cand[0])
                            break
    return res




# if __name__ == '__main__':
#     for domain in ['tiger', 'uav']:
    #     for time_slice in [3, 4]:
    #         get_result(domain=domain, time_slice=time_slice)
    # get_result(domain='uav', time_slice= 3)